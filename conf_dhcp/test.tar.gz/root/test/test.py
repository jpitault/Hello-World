#!/usr/bin/python3

nb = input('MAC address :')
install = input('Install : ')

with open("data", "a") as fichier:
	fichier.write("host testing {\n  hardware address ")
	fichier.write(nb)
	fichier.write(";\n  filename ")
	fichier.write(install)
	fichier.write(";\n}")
