#!/usr/bin/python3

with open("essai","r") as in_file, open("essai2","w") as out_file:
	for line in in_file.readlines():
		if "212" not in line :
			out_file.write(line)
