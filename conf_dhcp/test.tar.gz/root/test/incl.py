#!/usr/bin/python3
file = "data"
with open("dhcpd", "a") as fichier:
	fichier.write('include "/etc/{}";'.format(file))
