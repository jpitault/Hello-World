#!/usr/bin/python3
import subprocess


pattern= input("indication_ligne :")
pattern= '"'+ pattern
pattern= pattern + '"'
file=input("chemin_du_fichier :")
subprocess.run(["grep", "-v", pattern, file, ">", "/tmp/tmpfile", "&&", "mv", "/tmp/tmpfile", file])

