#!/bin/sh


echo "Cible pour désigner les lignes à supprimer :"

read cible

grep -v "$cible" /etc/dhcp/dhcpd.conf > temp && mv temp /etc/dhcp/dhcpd.conf

